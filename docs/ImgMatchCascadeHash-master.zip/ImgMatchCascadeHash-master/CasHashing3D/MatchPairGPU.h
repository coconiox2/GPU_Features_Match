void compute_hamming_distance_GPU(ImageData *, ImageData *, HashData *, HashData *, int , uint16_t*, uint8_t*, uint16_t*, cudaStream_t *);
