#include "Common.h"
void count_element_bucket_GPU(ImageData *, int *, int, int, int);