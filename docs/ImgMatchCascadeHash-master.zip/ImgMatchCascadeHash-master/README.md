# README
- To build, inside the directory, CascadeHashing3D, create folder "build". Then "cd build", "cmake .." and finally, "make".
- Currently timed to be 4.5 times faster than serial version for 432 images.
- Not tested for different values of bucketGroups
- Older versions of kernels have been left in 